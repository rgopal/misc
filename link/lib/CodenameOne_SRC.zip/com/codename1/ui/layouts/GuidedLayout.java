/*
 * Copyright (c) 2012, Codename One and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Codename One designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *  
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 * 
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 * 
 * Please contact Codename One through http://www.codenameone.com/ if you 
 * need additional information or have any questions.
 */

package com.codename1.ui.layouts;

import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Display;
import com.codename1.ui.Label;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.plaf.Style;
import java.util.ArrayList;

/**
 * Allows placing components based on guides and constraints in a similar way
 * to group layout. Unlike group layout this layout was designed with Codename One
 * in mind and its GUI builder.
 * <p>Unlike most other layout managers this layout manager is designed for usage
 * in full screen and not designed for nesting although it can be nested.
 *
 * @author Shai Almog
 */
public class GuidedLayout extends Layout {

    public static final int ALIGN_BEHAVIOR_NONE = 0;
    public static final int H_ALIGN_BEHAVIOR_CENTER = 1;
    public static final int H_ALIGN_BEHAVIOR_BASELINE = 2;
    public static final int H_ALIGN_BEHAVIOR_TOP = 3;
    public static final int H_ALIGN_BEHAVIOR_BOTTOM = 4;
    public static final int V_ALIGN_BEHAVIOR_CENTER = 1;
    public static final int V_ALIGN_BEHAVIOR_LEFT = 2;
    public static final int V_ALIGN_BEHAVIOR_RIGHT = 3;
    
    private final ArrayList<Attachments> att = new ArrayList<Attachments>();
    
    private Attachments getAttachment(Component cmp) {
        for(Attachments a : att) {
            if(a.destination == cmp) {
                return a;
            }
        }
        Attachments a = new Attachments();
        a.destination = cmp;
        att.add(a);
        return a;
    }
    

    public void setGrowHorizontal(Component c, boolean b) {
        getAttachment(c).growHorizontal = b;
    }
    
    public void setGrowVertical(Component c, boolean b) {
        getAttachment(c).growVertical = b;
    }
    
    public boolean isGrowHorizontal(Component c) {
        return getAttachment(c).growHorizontal;
    }
    
    public boolean isGrowVertical(Component c) {
        return getAttachment(c).growVertical;
    }

    public void setAttachLeft(Component cmp, boolean b) {
        getAttachment(cmp).leftEdge = b;
    }
    
    public void setAttachRight(Component cmp, boolean b) {
        getAttachment(cmp).rightEdge = b;
    }

    public void setAttachBottom(Component cmp, boolean b) {
        getAttachment(cmp).bottomEdge = b;
    }

    public void setAttachTop(Component cmp, boolean b) {
        getAttachment(cmp).topEdge = b;
    }
    
    public boolean isAttachTop(Component cmp) {
        return getAttachment(cmp).topEdge;
    }
    
    public boolean isAttachBottom(Component cmp) {
        return getAttachment(cmp).bottomEdge;
    }

    public boolean isAttachLeft(Component cmp) {
        return getAttachment(cmp).leftEdge;
    }

    public boolean isAttachRight(Component cmp) {
        return getAttachment(cmp).rightEdge;
    }
    
    public void setAttachLeftTo(Component to, Component source) {
        Attachments a = getAttachment(to);
        Attachments b = getAttachment(source);
        a.left = b;
        b.right = a;
    }
    
    public Component getAttachLeftTo(Component to) {
        Attachments a = getAttachment(to).left;
        if(a == null) {
            return null;
        }
        return a.destination;
    }

    public Component getAttachTopTo(Component to) {
        Attachments a = getAttachment(to).top;
        if(a == null) {
            return null;
        }
        return a.destination;
    }

    public void setAttachRightTo(Component to, Component source) {
        setAttachLeftTo(source, to);
    }

    public void setAttachTopTo(Component to, Component source) {
        Attachments a = getAttachment(to);
        Attachments b = getAttachment(source);
        a.top = b;
        b.bottom = a;
    }

    public void setAttachBottomTo(Component to, Component source) {
        setAttachTopTo(source, to);
    }
    
    public void setLeftAlignBehavior(Component c, int behavior) {
        getAttachment(c).hAlignBehaviorLeft = behavior;
    }

    public void setRightAlignBehavior(Component c, int behavior) {
        getAttachment(c).hAlignBehaviorRight = behavior;
    }
    
    public void setTopAlignBehavior(Component c, int behavior) {
        getAttachment(c).vAlignBehaviorTop = behavior;
    }
    
    public void setBottomAlignBehavior(Component c, int behavior) {
        getAttachment(c).vAlignBehaviorBottom = behavior;
    }
    
    public void setAttachHorizontalCenter(Component cmp, boolean b) {
        getAttachment(cmp).hCenterAttach = b;
    }

    public boolean isAttachHorizontalCenter(Component cmp) {
        return getAttachment(cmp).hCenterAttach;
    }
    
    public void setAttachVerticalCenter(Component cmp, boolean b) {
        getAttachment(cmp).vCenterAttach = b;
    }

    public boolean isAttachVerticalCenter(Component cmp) {
        return getAttachment(cmp).vCenterAttach;
    }
    
    public void clearAttachments(Component cmp) {
        Attachments a = getAttachment(cmp);
        att.remove(a);
        for(Attachments current : att) {
            if(current.right == a) {
                current.right = a.right;
            }
            if(current.bottom == a) {
                current.bottom = a.bottom;
            }
            if(current.left == a) {
                if(a.left == null) {
                    current.left = null;
                } else {
                    current.left = a.left;
                }
                current.leftEdge = a.leftEdge;
                current.vCenterAttach = a.vCenterAttach;
                current.hCenterAttach = a.hCenterAttach;
            } else {
                if(a.left == current) {
                    current.leftEdge |= a.leftEdge;
                    current.vCenterAttach |= a.vCenterAttach;
                    current.hCenterAttach |= a.hCenterAttach;
                }
            }
            if(current.top == a) {
                if(a.top == null) {
                    current.top = null;
                } else {
                    current.top = a.top;
                }
                current.topEdge = a.topEdge;
                current.hCenterAttach = a.hCenterAttach;
                current.hCenterAttach = a.hCenterAttach;
            } else {
                if(a.top == current) {
                    current.topEdge |= a.topEdge;
                    current.vCenterAttach |= a.vCenterAttach;
                    current.hCenterAttach |= a.hCenterAttach;
                }
            }
        }
        a.right = null;
        a.bottom = null;
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public void layoutContainer(Container parent) {
        Style parentStyle = parent.getStyle();
        int startX = parentStyle.getPadding(Component.LEFT);
        int startY = parentStyle.getPadding(Component.TOP);
        int parentWidth = parent.getWidth() - startX - parentStyle.getPadding(Component.RIGHT);
        int parentHeight = parent.getHeight() - startY - parentStyle.getPadding(Component.BOTTOM);
                
        // remove unused attachments
        for(int iter = 0 ; iter < att.size() ; iter++) {
            Attachments a = att.get(iter);
            if(a.destination.getParent() != parent) {
                att.remove(iter);
                iter--;
            }
        }
        
        System.out.println("*** Attachment list ***");
        // iterate over attachments for first stage of layout
        for(Attachments a : att) {
            System.out.println(a);
            a.reset();
            a.initHardConstraint(parent, startX, startY, parentWidth, parentHeight);
        }
        
        // init the row heights and column widths
        for(Attachments a : att) {
            if(a.rowHeight == Integer.MIN_VALUE) {
                if(a.left != null) {
                    Attachments aa = a;
                    while(aa.left != null) {
                        aa.left.right = aa;
                        aa = aa.left;
                    }
                    int prefHeight = aa.destination.getPreferredH();
                    aa = aa.right;
                    while(aa.right != null) {
                        prefHeight = Math.max(aa.right.destination.getPreferredH(), prefHeight);
                        aa = aa.right;
                    }
                    prefHeight = Math.max(aa.destination.getPreferredH(), prefHeight);
                    
                    while(aa.left != null) {
                        aa.rowHeight = prefHeight;
                        aa = aa.left;
                    }
                }
            }
            if(a.columnWidth == Integer.MIN_VALUE) {
                if(a.top != null) {
                    Attachments aa = a;
                    while(aa.top != null) {
                        aa.top.bottom = aa;
                        aa = aa.top;
                    }
                    int prefWidth = aa.destination.getPreferredW();
                    aa = aa.bottom;
                    while(aa.bottom != null) {
                        prefWidth = Math.max(aa.bottom.destination.getPreferredW(), prefWidth);
                        aa = aa.bottom;
                    }
                    prefWidth = Math.max(aa.destination.getPreferredW(), prefWidth);
                    
                    while(aa.top != null) {
                        aa.columnWidth = prefWidth;
                        aa = aa.top;
                    }
                }
            }
        }
        
        for(Attachments a : att) {
            a.initKnownSizes(parent, startX, startY, parentWidth, parentHeight);
        }
        
        for(Attachments a : att) {
            a.layoutAttachments(parentWidth, parentHeight);
        }

        // final loop, apply the layout constraints to the components
        for(Attachments a : att) {
            a.applyLayout();
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public Dimension getPreferredSize(Container parent) {
        Display d = Display.getInstance();
        return new Dimension(d.getDisplayWidth(), d.getDisplayHeight());
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean obscuresPotential(Container parent) {
        return super.obscuresPotential(parent); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean isConstraintTracking() {
        return false;
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean isOverlapSupported() {
        return false;
    }

    /**
     * @inheritDoc
     */
    @Override
    public Object getComponentConstraint(Component comp) {
        return null;
    }

    /**
     * @inheritDoc
     */
    @Override
    public void removeLayoutComponent(Component comp) {
        //att.remove(getAttachment(comp));
        super.removeLayoutComponent(comp); 
    }

    /**
     * @inheritDoc
     */
    @Override
    public void addLayoutComponent(Object value, Component comp, Container c) {
        //getAttachment(comp);
        super.addLayoutComponent(value, comp, c); 
    }
    
    /**
     * Defines the layout constraint for the guided layout
     */
    static class Attachments {
        Component destination;
        
        // component attached to this component on the left, right top and bottom sides
        Attachments left;
        Attachments top;
        
        // allow bidirectional navigation of row/column but have no actual effect on layout
        Attachments right;
        Attachments bottom;

        boolean leftEdge;
        boolean rightEdge;
        boolean topEdge;
        boolean bottomEdge;

        boolean hCenterAttach;
        boolean vCenterAttach;

        Attachments[] align;
        int alignDirection;        
        boolean growHorizontal;
        boolean growVertical;
        
        int vAlignBehaviorTop;
        int vAlignBehaviorBottom;
        int hAlignBehaviorRight;
        int hAlignBehaviorLeft;
        
        private int width;
        private int height;
        private int x1;
        private int y1;
        private int x2;
        private int y2;
        
        private int marginLeft;
        private int marginRight;
        private int marginTop;
        private int marginBottom;

        int rowStart;
        int columnStart;
        int rowHeight;
        int columnWidth;

        Attachments alignLeft;
        Attachments alignRight;
        Attachments alignCenter;
        Attachments alignTop;
        Attachments alignBottom;
        Attachments alignVCenter;
        
        private void cmpToString(StringBuilder b, Component d) {
            if(d.getName() != null) {
                b.append(d.getName());
                b.append(":");
            } else {
                if(d instanceof Label) {
                    if(((Label)d).getText() != null && ((Label)d).getText().length() > 0) {
                        b.append(((Label)d).getText());
                    } else {
                        b.append(d.toString());
                    }
                    b.append(":");
                }
            }
        }
        
        public String toString() {
            StringBuilder b = new StringBuilder();
            cmpToString(b, destination);
            if(left != null) {
                b.append(" left attach - ");
                cmpToString(b, left.destination);
            }
            if(top != null) {
                b.append(" top attach - ");
                cmpToString(b, top.destination);
            }
            if(topEdge) {
                b.append(" top edge");
            }
            if(bottomEdge) {
                b.append(" bottom edge");
            }
            if(leftEdge) {
                b.append(" left edge");
            }
            if(rightEdge) {
                b.append(" right edge");
            }
            if(hCenterAttach) {
                b.append(" horizontal center");
            }
            if(vCenterAttach) {
                b.append(" vertical center");
            }
            
            switch(vAlignBehaviorTop) {
                case V_ALIGN_BEHAVIOR_CENTER:
                    b.append(" top align center");
                    break;
                            
                case V_ALIGN_BEHAVIOR_LEFT:
                    b.append(" top align left");
                    break;
                            
                case V_ALIGN_BEHAVIOR_RIGHT:
                    b.append(" top align right");
                    break;
            }

            switch(vAlignBehaviorBottom) {
                case V_ALIGN_BEHAVIOR_CENTER:
                    b.append(" bottom align center");
                    break;
                            
                case V_ALIGN_BEHAVIOR_LEFT:
                    b.append(" bottom align left");
                    break;
                            
                case V_ALIGN_BEHAVIOR_RIGHT:
                    b.append(" bottom align right");
                    break;
            }

            switch(hAlignBehaviorLeft) {
                case H_ALIGN_BEHAVIOR_BASELINE:
                    b.append(" left align baseline");
                    break;                    
                case H_ALIGN_BEHAVIOR_BOTTOM:
                    b.append(" left align bottom");
                    break;                    
                case H_ALIGN_BEHAVIOR_CENTER:
                    b.append(" left align center");
                    break;                    
                case H_ALIGN_BEHAVIOR_TOP:
                    b.append(" left align top");
                    break;                    
            }

            switch(hAlignBehaviorRight) {
                case H_ALIGN_BEHAVIOR_BASELINE:
                    b.append(" right align baseline");
                    break;                    
                case H_ALIGN_BEHAVIOR_BOTTOM:
                    b.append(" right align bottom");
                    break;                    
                case H_ALIGN_BEHAVIOR_CENTER:
                    b.append(" right align center");
                    break;                    
                case H_ALIGN_BEHAVIOR_TOP:
                    b.append(" right align top");
                    break;                    
            }
            return b.toString();
        }
        
        public void reset() {
            x1 = Integer.MIN_VALUE;
            x2 = Integer.MIN_VALUE;
            y1 = Integer.MIN_VALUE;
            y2 = Integer.MIN_VALUE;
            width = Integer.MIN_VALUE;
            height = Integer.MIN_VALUE;
            rowHeight = Integer.MIN_VALUE;
            columnWidth = Integer.MIN_VALUE;
            rowStart = Integer.MIN_VALUE;
            columnStart = Integer.MIN_VALUE;
            Style s = destination.getStyle();
            marginLeft = s.getMargin(Component.LEFT);
            marginRight = s.getMargin(Component.RIGHT);
            marginTop = s.getMargin(Component.TOP);
            marginBottom = s.getMargin(Component.BOTTOM);
        }
        
        public void initHardConstraint(Container parent, int startX, int startY, int width, int height) {
            if(leftEdge) {
                x1 = startX + marginLeft;
                columnStart = x1;
            }
            if(rightEdge) {
                x2 = startX + width - marginRight;
            }
            if(topEdge) {
                y1 = startY + marginTop;
                rowStart  = y1;
            }
            if(bottomEdge) {
                y2 = startY + height - marginBottom;
            }    
        }
        
        
        public void initKnownSizes(Container parent, int startX, int startY, int parentWidth, int parentHeight) {
            // takes up full width
            if(leftEdge && rightEdge) {
                width = parentWidth;
            } else {
                if(!growHorizontal) {
                    width = destination.getPreferredW();
                }
            }
            // takes up full height 
            if(topEdge && bottomEdge) {
                height = parentHeight;
            } else {
                if(!growVertical) {
                    height = destination.getPreferredH();
                }
            }
        }
        
        private int getRowStartImpl(int pos) {
            if(rowStart != Integer.MIN_VALUE) {
                return rowStart;
            }
            if(top != null) {
                int topP = top.getRowStart();
                if(topP != Integer.MIN_VALUE) {
                    topP = top.y1;
                }
                topP += top.getRowHeight();
                if(topP > pos) {
                    pos = topP;
                }
            }
            if(left != null) {
                return left.getRowStartImpl(pos);
            }
            return pos;
        }
        
        private int getRowStart() {
            if(right != null) {
                Attachments aa = this;
                while(aa.right != null) {
                    aa = aa.right;
                }
                rowStart = aa.getRowStartImpl(Integer.MIN_VALUE);
                return rowStart;
            }
            rowStart = getRowStartImpl(getY1());
            return rowStart;
        }
        
        private int getRowHeight(int def) {
            if(rowHeight != Integer.MIN_VALUE) {
                return rowHeight;
            }
            if(left == null) {
                return def;
            }
            return left.getRowHeight(def);
        }
        
        private int getRowHeight() {
            return getRowHeight(getHeight());
        }
        
        private int getColumnWidth(int def) {
            if(columnWidth != Integer.MIN_VALUE) {
                return columnWidth;
            }
            if(top == null) {
                return def;
            }
            return top.getColumnWidth(def);
        }

        private int getColumnWidth() {
            return getColumnWidth(getWidth());
        }
        
        private int getX2() {
            if(x2 != Integer.MIN_VALUE) {
                return x2;
            }
            if(x1 != Integer.MIN_VALUE && width != Integer.MIN_VALUE) {
                x2 = x1 + width;
                return x2;
            }
            return Integer.MIN_VALUE;
        }

        private int getX1() {
            if(x1 != Integer.MIN_VALUE) {
                return x1;
            }
            if(x2 != Integer.MIN_VALUE && width != Integer.MIN_VALUE) {
                x1 = x2 - width;
                return x1;
            }
            return Integer.MIN_VALUE;
        }
        
        private int getY2() {
            if(y2 != Integer.MIN_VALUE) {
                return y2;
            }
            if(y1 != Integer.MIN_VALUE && height != Integer.MIN_VALUE) {
                y2 = y1 + height;
                return y2;
            }
            return Integer.MIN_VALUE;
        }

        private int getY1() {
            if(y1 != Integer.MIN_VALUE) {
                return y1;
            }
            if(y2 != Integer.MIN_VALUE && height != Integer.MIN_VALUE) {
                y1 = y2 - height;
                return y1;
            }
            return Integer.MIN_VALUE;
        }
        
        private int getWidth() {
            if(width != Integer.MIN_VALUE) {
                return width;
            }
            if(getX1() != Integer.MIN_VALUE && getX2() != Integer.MIN_VALUE) {
                width = x2 - x1;
                return width;
            }
            width = destination.getPreferredW();
            return width;
        }
        
        private int getHeight() {
            if(height != Integer.MIN_VALUE) {
                return height;
            }
            if(getY1() != Integer.MIN_VALUE && getY2() != Integer.MIN_VALUE) {
                height = y2 - y1;
                return height;
            }
            height = destination.getPreferredH();
            return height;
        }
        
        public void layoutAttachments(int parentWidth, int parentHeight) {
            if(hCenterAttach) {
                if(width == Integer.MIN_VALUE) {
                    width = destination.getPreferredW();
                }
                x1 = parentWidth / 2 - width / 2;
                x2 = x1 + width;
            }
            
            if(vCenterAttach) {
                if(height == Integer.MIN_VALUE) {
                    height = destination.getPreferredH();
                }
                y1 = parentHeight / 2 - height / 2;
                y2 = y1 + height;
            }

            if(left != null) {
                if(left.getX1() != Integer.MIN_VALUE) { 
                   int x2Pos = left.getX2();
                    if(x2Pos != Integer.MIN_VALUE) {
                        x1 = x2Pos - marginRight - left.marginLeft;
                    }
                } else {
                    left.x2 = getX1();
                }
                if(y1 == Integer.MIN_VALUE && hAlignBehaviorLeft != ALIGN_BEHAVIOR_NONE) {
                    initHAlign(hAlignBehaviorLeft, this, left);
                } else {
                    if(left.y1 == Integer.MIN_VALUE) {
                        initHAlign(hAlignBehaviorRight, left, this);                        
                    }
                }
            }
            if(top != null) {
                if(top.y1 != Integer.MIN_VALUE) {
                    int y2Pos = top.getRowStart();
                    if(y2Pos != Integer.MIN_VALUE) {
                        int h = top.getRowHeight();
                        if(y2Pos != Integer.MIN_VALUE) {
                            y2Pos += h;
                        } else {
                            y2Pos = top.getY2();
                        }
                    } else {
                        y2Pos = top.getY2();
                    }
                    if(y2Pos != Integer.MIN_VALUE) {
                        y1 = y2Pos - marginTop - top.marginBottom;
                    }
                } else {
                    top.y2 = getY1();
                }
                if(x1 == Integer.MIN_VALUE && vAlignBehaviorTop != ALIGN_BEHAVIOR_NONE) {
                    initVAlign(vAlignBehaviorTop, this, top);
                } else {
                    if(top.x1 == Integer.MIN_VALUE) {
                        initVAlign(vAlignBehaviorBottom, top, this);
                    }
                }
            }
        }

        private static void initVAlign(int align, Attachments src, Attachments lead) {
            switch(align) {
                case V_ALIGN_BEHAVIOR_CENTER:
                    int xx1 = lead.getY1();
                    int xx2 = lead.getY2();
                    int thisWidth = src.getWidth();
                    if(thisWidth > xx2 - xx1) {
                        src.x1 = xx1 - thisWidth / 2 - (xx2 - xx1) / 2;
                    } else {
                        src.x1 = xx1 + (xx2 - xx1) / 2 - thisWidth / 2;
                    }
                    break;
                case V_ALIGN_BEHAVIOR_LEFT:
                    src.x1 = lead.getX1();
                    break;
                case V_ALIGN_BEHAVIOR_RIGHT:
                    src.x2 = lead.getX2();
                    break;
            }
        }
        
        private static void initHAlign(int align, Attachments src, Attachments lead) {
            switch(align) {
                // TODO: We need to properly support baseline
                case H_ALIGN_BEHAVIOR_BASELINE:
                case H_ALIGN_BEHAVIOR_CENTER: {
                    int yy1 = lead.getY1();
                    int yy2 = lead.getY2();
                    int rowH = yy2 - yy1;
                    int rowStart = lead.getRowStart();
                    if(rowStart != Integer.MIN_VALUE && lead.getRowHeight() != Integer.MIN_VALUE) {
                        yy1 = rowStart;
                        rowH = lead.getRowHeight();
                        yy2 = rowStart + rowH;
                    }
                    int thisHeight = src.getHeight();
                    if(thisHeight > yy2 - yy1) {
                        src.y1 = yy1 - (thisHeight / 2 - rowH / 2);
                    } else {
                        src.y1 = yy1 + (rowH / 2 - thisHeight / 2);
                    }
                    break;
                }
                case H_ALIGN_BEHAVIOR_TOP:
                    if(lead.rowStart != Integer.MIN_VALUE) {
                        src.y1 = lead.rowStart;
                    } else {
                        src.y1 = lead.getY1();
                    }
                    break;
                case H_ALIGN_BEHAVIOR_BOTTOM:
                    if(lead.rowStart != Integer.MIN_VALUE && lead.getRowHeight() != Integer.MIN_VALUE) {
                        src.y2 = lead.rowStart + lead.getRowHeight();
                    } else {
                        src.y2 = lead.getY2();
                    }
                    break;
            }            
        }
        
        public void applyLayout() {
            if(x1 == Integer.MIN_VALUE) {
                if(width != Integer.MIN_VALUE) {
                    if(x2 != Integer.MIN_VALUE) {
                        x1 = x2 - width;
                    } else {
                        x2 = x1 + width;
                    }
                } else {
                    if(x2 != Integer.MIN_VALUE) {
                        width = destination.getPreferredW();
                        x1 = x2 - width;
                    } 
                }
            } else {
                if(x2 == Integer.MIN_VALUE) {
                    if(width == Integer.MIN_VALUE) {
                        width = destination.getPreferredW();
                    }
                    x2 = x1 + width;
                }
            }

            if(y1 == Integer.MIN_VALUE) {
                if(height != Integer.MIN_VALUE) {
                    if(y2 != Integer.MIN_VALUE) {
                        y1 = y2 - height;
                    } else {
                        y1 = 0;
                        y2 += height;
                    }
                } else {
                    if(y2 == Integer.MIN_VALUE) {
                        if(height == Integer.MIN_VALUE) {
                            height = destination.getPreferredH();
                        }
                        y1 = 0;
                        y2 = height;
                    } 
                }
            } else {
                if(y2 == Integer.MIN_VALUE) {
                    if(height == Integer.MIN_VALUE) {
                        height = destination.getPreferredH();
                    }
                    y2 = y1 + height;
                }
            }

            
            if(x1 == Integer.MIN_VALUE) {
                //throw new RuntimeException("Missing constraint on " + destination);
                System.out.println("Missing X1 constraint on " + destination);
                x1 = 0;
            }
            if(y1 == Integer.MIN_VALUE) {
                //throw new RuntimeException("Missing constraint on " + destination);
                System.out.println("Missing Y1 constraint on " + destination);
                y1 = 0;
            }
            
            if(width == Integer.MIN_VALUE) {
                width = x2 - x1;
            }
            if(height == Integer.MIN_VALUE) {
                height = y2 - y1;
            }
            
            destination.setWidth(width);
            destination.setHeight(height);
            destination.setX(x1);
            destination.setY(y1);
        }
    }
}
